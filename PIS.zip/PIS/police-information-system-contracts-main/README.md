# Police Information System Contract

This repo contains the smart contracts for the police information system project and they are deployed on mumbai network.

## Tech used

-   hardhat
-   hardhat deploy
-   openzeppelin contracts
-   Typescript

## Dev packages

-   dotenv
-   hardhat ethers
